<?php

class User_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function totalBayar($id)
    {
        $query = $this->db->query("SELECT sum(jumlah) total FROM troli, user WHERE user.id=troli.id_user AND user.email='" . $id . "'");
        $row = $query->row(1);
        return $row;
    }
    function totalBelanja($id)
    {
        $query = $this->db->query("SELECT count(*) total FROM troli, user WHERE user.id=troli.id_user AND user.email='" . $id . "'");
        $row = $query->result_array();
        return $row;
    }
}
