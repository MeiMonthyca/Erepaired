<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Projekfull extends CI_Controller
{
    public function index()
    {
        $this->load->view('templates/header');
        $this->load->view('projekfull/project-full-width');
        $this->load->view('templates/footer');
    }
}
