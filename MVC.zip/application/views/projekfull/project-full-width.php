    <!--================Banner Area =================-->
    <section class="banner_area">
        <div class="container">
            <div class="banner_inner_text">
                <h4>Layanan kami</h4>
                <ul>
                    <li><a href="<?= base_url('Utama') ?>">Home</a></li>

                </ul>
            </div>
        </div>
    </section>
    <!--================End Banner Area =================-->

    <!--================Our Project2 Area =================-->
    <section class="our_project2_area our_project_two_column">


        <div class="our_project_details">
            <div class="col-md-6 building isolation interior">
                <div class="project_item">
                    <img src="<?= base_url('assets/') ?>img/project/project-two-column/project-two-1.jpg" alt="">
                    <div class="project_hover">
                        <div class="project_hover_inner">
                            <div class="project_hover_content">
                                <a href="#">
                                    <h4>Kontruksi</h4>
                                </a>
                                <p>Disini kami akan memberikan para ahli yang akan membantu anda dalam hal kontruksi</p>
                                <a class="view_btn" href="<?= base_url('Kontruksi') ?>">View Project</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 building isolation tiling design">
                <div class="project_item">
                    <img src="<?= base_url('assets/') ?>img/project/project-two-column/project-two-2.jpg" alt="">
                    <div class="project_hover">
                        <div class="project_hover_inner">
                            <div class="project_hover_content">
                                <a href="#">
                                    <h4>Furnitur</h4>
                                </a>
                                <p>Disini kami akan memberikan para ahli yang akan mambantu anda dalam hal memperbaiki alt-alat furnitur di rumah anda</p>
                                <a class="view_btn" href="<?= base_url('Furnitur') ?>">View Project</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 isolation tiling interior design plumbing">
                <div class="project_item">
                    <img src="<?= base_url('assets/') ?>img/project/project-two-column/Elektronik.png" alt="">
                    <div class="project_hover">
                        <div class="project_hover_inner">
                            <div class="project_hover_content">
                                <a href="#">
                                    <h4>Elektronik</h4>
                                </a>
                                <p>Disini kami akan memberikan para ahli yang akan membantu anda dalam hal memperbaiki alat-alat elektronik anda</p>
                                <a class="view_btn" href="<?= base_url('Elektronik') ?>">View Project</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 building isolation tiling plumbing">
                <div class="project_item">
                    <img src="<?= base_url('assets/') ?>img/project/project-two-column/Transportasi2.jpg" alt="">
                    <div class="project_hover">
                        <div class="project_hover_inner">
                            <div class="project_hover_content">
                                <a href="#">
                                    <h4>Transportasi</h4>
                                </a>
                                <p>Disini kami akan memberikan para ahli yang akan membantu anda dalam hal memperbaiki alat transportasi anda</p>
                                <a class="view_btn" href="<?= base_url('Transportasi') ?>">View Project</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    </section>
    <!--================End Our Project2 Area =================-->