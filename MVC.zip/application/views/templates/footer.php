 <!--================Footer Area =================-->
 <footer class="footer_area">
     <div class="footer_widgets_area">
         <div class="container">
             <div class="row footer_widgets_inner">
                 <div class="col-md-3 col-sm-6">
                     <aside class="f_widget about_widget">
                         <img src="img/footer-logo.png" alt="">
                         <p>E-REPAIRED adalah website jasa yang dibuat untuk membantu pelanggan yang
                             sedang mencari tukang untuk kebutuhannya secara simple dan efisien ,contohnya untuk
                             memperbaiki genteng, perabot seperti meja,kursi,tempat tidur,dll, dan juga jika ingin
                             membangun rumah maupun bagi seorang wirausahawan yang ingin membuat kios baru
                             maupun toko baru.
                         </p>
                         <ul>
                             <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                             <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                             <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                             <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                         </ul>
                     </aside>
                 </div>

                 <div class="col-md-3 col-sm-6">

                 </div>
                 <div class="col-md-3 col-sm-6">
                     <aside class="f_widget give_us_widget">
                         <h5>Give Us A Call</h5>
                         <h4>(012) 3456789</h4>
                         <h5></h5>

                     </aside>
                 </div>
             </div>
         </div>
     </div>
     <div class="footer_copy_right">
         <div class="container">
             <h4>
                 <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                 Copyright &copy;<script>
                     document.write(new Date().getFullYear());
                 </script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                 <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
             </h4>
         </div>
     </div>
 </footer>
 <!--================End Footer Area =================-->









 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
 <script src="<?= base_url('assets/') ?>js/jquery-2.2.4.js"></script>
 <!-- Include all compiled plugins (below), or include individual files as needed -->
 <script src="<?= base_url('assets/') ?>js/bootstrap.min.js"></script>
 <!-- Rev slider js -->
 <script src="<?= base_url('assets/') ?>vendors/revolution/js/jquery.themepunch.tools.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/revolution/js/jquery.themepunch.revolution.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/revolution/js/extensions/revolution.extension.video.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/revolution/js/extensions/revolution.extension.navigation.min.js"></script>

 <script src="<?= base_url('assets/') ?>vendors/owl-carousel/owl.carousel.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/isotope/imagesloaded.pkgd.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/isotope/isotope.pkgd.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/magnific-popup/jquery.magnific-popup.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/counterup/waypoints.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/counterup/jquery.counterup.min.js"></script>
 <script src="<?= base_url('assets/') ?>vendors/flex-slider/jquery.flexslider-min.js"></script>

 <!--gmaps Js-->
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
 <script src="<?= base_url('assets/') ?>js/gmaps.min.js"></script>

 <script src="<?= base_url('assets/') ?>js/theme.js"></script>
 </body>

 </html>