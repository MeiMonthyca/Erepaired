        <!--================Banner Area =================-->
        <section class="banner_area">
            <div class="container">
                <div class="banner_inner_text">
                    <h4>Kontruksi</h4>
                    <ul>
                        <li><a href="<?= base_url('Utama') ?>">Home</a></li>
                        <li class="active"><a href="<?= base_url('Projekfull') ?>">Projek full</a></li>
                    </ul>
                </div>
            </div>
        </section>
        <!--================End Banner Area =================-->

        <!--================PreConstruction Area =================-->
        <section class="preconstruction_area">
            <div class="row pre_construction_inner">
                <div class="col-md-6">
                    <div class="pre_construction_item">
                        <img src="<?= base_url('assets/') ?>img/pre-cons-left.jpg" alt="">
                        <div class="pre_hover">
                            <h4>kontruksi</h4>
                            <p>Disini kami akan menjamin memberikan para ahli yang pasti bisa membantu anda dalam memperbaiki rumah maupun bangunan </p>

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="pre_construction_right">
                        <img src="<?= base_url('assets/') ?>img/pre-cons-right.jpg" alt="">
                        <div class="pre_hover">
                            <form action="" method="post">
                                <p>harga yang kami berikan pasti menarik dan terjangkau dikalanagan manapun</p>
                                <a class="slider_btn" href="<?= base_url('Blog') ?>">Pesan</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End PreConstruction Area =================-->